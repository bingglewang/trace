create view goods_detail as
  select
    `g`.`goods_id`            AS `goods_id`,
    `g`.`goods_name`          AS `goods_name`,
    `g`.`merchant_id`         AS `merchant_id`,
    `g`.`category_id`         AS `category_id`,
    `g`.`category_full_name`  AS `category_full_name`,
    `g`.`goods_creat_time`    AS `goods_creat_time`,
    `g`.`goods_update_time`   AS `goods_update_time`,
    `g`.`brand_id`            AS `brand_id`,
    `b`.`brand_name`          AS `brand_name`,
    `c`.`category_name`       AS `category_name`,
    `gin`.`introduction_info` AS `introduction_info`,
    `gi`.`image_index`        AS `image_index`,
    `gi`.`image_url`          AS `image_url`,
    `p`.`property_name`       AS `property_name`,
    `mcp`.`enter_type`        AS `enter_type`,
    `pv`.`combobox_value`     AS `combobox_value`,
    `mgpv`.`textbox_value`    AS `textbox_value`
  from (((((((
      (`traceability_platform`.`goods` `g` left join `traceability_platform`.`middle_goods_property_value` `mgpv`
          on ((`g`.`goods_id` = `mgpv`.`goods_id`))) left join `traceability_platform`.`property_value` `pv`
        on ((`pv`.`property_value_id` = `mgpv`.`property_value_id`))) left join
    `traceability_platform`.`middle_category_property` `mcp`
      on ((`mcp`.`category_property_id` = `pv`.`category_property_id`))) left join
    `traceability_platform`.`property` `p` on ((`p`.`property_id` = `mcp`.`property_id`))) left join
    `traceability_platform`.`category` `c` on ((`c`.`category_id` = `g`.`category_id`))) left join
    `traceability_platform`.`goods_image` `gi` on ((`g`.`goods_id` = `gi`.`goods_id`))) left join
    `traceability_platform`.`goods_introduction` `gin` on ((`gin`.`goods_id` = `g`.`goods_id`))) left join
    `traceability_platform`.`brand` `b` on ((`g`.`brand_id` = `b`.`brand_id`)));

