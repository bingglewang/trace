create view merchant_detail as
  select
    `m`.`merchant_id`                                                                                           AS `merchant_id`,
    `m`.`merchant_name`                                                                                         AS `merchant_name`,
    `m`.`merchant_account`                                                                                      AS `merchant_account`,
    `m`.`merchant_detail_site`                                                                                  AS `merchant_detail_site`,
    `m`.`merchant_url`                                                                                          AS `merchant_url`,
    (case `mt`.`enterprise`
     when 0
       then '非企业'
     when 1
       then '企业'
     else NULL end)                                                                                             AS `enterprise`,
    `m`.`net_type`                                                                                              AS `net_type`,
    `m`.`merchant_coin`                                                                                         AS `merchant_coin`,
    `m`.`alliance_business_id`                                                                                  AS `alliance_business_id`,
    `m`.`merchant_type`                                                                                         AS `merchant_type`,
    `m`.`leal_person_name`                                                                                      AS `leal_person_name`,
    `m`.`papers_url`                                                                                            AS `papers_url`,
    `m`.`papers_back_url`                                                                                       AS `papers_back_url`,
    `m`.`papers_number`                                                                                         AS `papers_number`,
    `m`.`business_lines`                                                                                        AS `business_lines`,
    `m`.`merchant_contact`                                                                                      AS `merchant_contact`,
    `m`.`contact_number`                                                                                        AS `contact_number`,
    `m`.`merchant_enter_time`                                                                                   AS `merchant_enter_time`,
    `m`.`merchant_status`                                                                                       AS `merchant_status`,
    `m`.`short_video_url`                                                                                       AS `short_video_url`,
    `m`.`certification_to_pay`                                                                                  AS `certification_to_pay`,
    `m`.`merchant_desciption`                                                                                   AS `merchant_desciption`,
    `m`.`stall_limit`                                                                                           AS `stall_limit`,
    `m`.`paper_label_upper`                                                                                     AS `paper_label_upper`,
    `mpg`.`papers_group_id`                                                                                     AS `papers_group_id`,
    `mpg`.`merchant_id`                                                                                         AS `mpg_merchant_id`,
    `mpg`.`merchant_logo_url`                                                                                   AS `merchant_logo_url`,
    `mpg`.`product_test_report_url`                                                                             AS `product_test_report_url`,
    `mpg`.`hygienic_license_url`                                                                                AS `hygienic_license_url`,
    `mpg`.`business_certificate_url`                                                                            AS `business_certificate_url`,
    `mpg`.`product_certification_url`                                                                           AS `product_certification_url`,
    `mpg`.`production_licence_url`                                                                              AS `production_licence_url`,
    `mpg`.`warenzeichenlizenz_url`                                                                              AS `warenzeichenlizenz_url`,
    `mi`.`merchant_image_id`                                                                                    AS `merchant_image_id`,
    `mi`.`merchant_id`                                                                                          AS `mi_merchant_id`,
    `mi`.`merchant_image_url`                                                                                   AS `merchant_image_url`,
    `mi`.`merchant_image_index`                                                                                 AS `merchant_image_index`,
    `mt`.`merchant_type`                                                                                        AS `merchant_type_str`,
    `b`.`brand_id`                                                                                              AS `brand_id`,
    `b`.`brand_name`                                                                                            AS `brand_name`,
    `b`.`merchant_id`                                                                                           AS `b_merchant_id`,
    `nt`.`merchant_type`                                                                                        AS `net_type_str`,
    `traceability_platform`.`country`.`countryID`                                                               AS `countryID`,
    `traceability_platform`.`country`.`country`                                                                 AS `country`,
    `traceability_platform`.`province`.`provinceID`                                                             AS `provinceID`,
    `traceability_platform`.`province`.`province`                                                               AS `province`,
    `traceability_platform`.`city`.`cityID`                                                                     AS `cityID`,
    `traceability_platform`.`city`.`city`                                                                       AS `city`,
    `m`.`adminstration_id`                                                                                      AS `adminstration_id`,
    `traceability_platform`.`area`.`area`                                                                       AS `area`,
    concat_ws(',', `traceability_platform`.`country`.`countryID`, `traceability_platform`.`province`.`provinceID`,
              `traceability_platform`.`city`.`cityID`,
              `m`.`adminstration_id`)                                                                           AS `administrative_division_full_site`,
    concat_ws(' ', `traceability_platform`.`country`.`country`, `traceability_platform`.`province`.`province`,
              `traceability_platform`.`city`.`city`, convert(`traceability_platform`.`area`.`area` using
                                                             utf8))                                             AS `area_full`
  from (((((((((`traceability_platform`.`merchant` `m` left join `traceability_platform`.`merchant_papers_group` `mpg`
      on ((`mpg`.`merchant_id` = `m`.`merchant_id`))) left join `traceability_platform`.`merchant_image` `mi`
      on ((`mi`.`merchant_id` = `m`.`merchant_id`))) left join `traceability_platform`.`merchant_type` `mt`
      on ((`mt`.`merchant_type_id` = `m`.`merchant_type`))) left join `traceability_platform`.`brand` `b`
      on ((`b`.`merchant_id` = `m`.`merchant_id`))) left join `traceability_platform`.`merchant_type` `nt`
      on ((`nt`.`merchant_type_id` = `m`.`net_type`))) left join `traceability_platform`.`area`
      on ((`m`.`adminstration_id` = `traceability_platform`.`area`.`areaID`))) left join `traceability_platform`.`city`
      on ((`traceability_platform`.`area`.`fatherID` = `traceability_platform`.`city`.`cityID`))) left join
    `traceability_platform`.`province`
      on ((`traceability_platform`.`city`.`fatherID` = `traceability_platform`.`province`.`provinceID`))) left join
    `traceability_platform`.`country`
      on ((`traceability_platform`.`province`.`fatherID` = `traceability_platform`.`country`.`countryID`)));

